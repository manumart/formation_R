### R code from vignette source 'formationR.Rnw'

###################################################
### code chunk number 1: exemple
###################################################
par(mfrow=c(1,2))
hist(rnorm(100), main="")
hist(rnorm(1000), main="")


